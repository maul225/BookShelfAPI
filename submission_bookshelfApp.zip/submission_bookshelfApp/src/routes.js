const { addbookHandler,
    getAllBooksHandler, 
    getBookByIdHandler,
    editbookHandler, 
    deletebookHandler,
    } = require('./handler');

const routes = [
    {
        method: 'POST',
        path: '/books',
        handler: addbookHandler,
    },
    {
        method: 'GET',
        path: '/books',
        handler: getAllBooksHandler,
    },
    {
        method: 'GET',
        path: '/books/{id}',
        handler: getBookByIdHandler,
    },
    {
        method: 'PUT',
        path: '/books/{id}',
        handler: editbookHandler,
    },
    {
        method: 'DELETE',
        path: '/books/{id}',
        handler: deletebookHandler,
    }
];

module.exports = routes;